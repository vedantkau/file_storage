import sqlite3 as sq
import logging
import os

logger = logging.getLogger(__name__)


def _hash_row(concat_value: str) -> hash:
    """
    Returns hash of given string (concatenated value).
    """
    return hash(concat_value)


def lambda_handler(event, context):
    # download database from s3 if exists
    import botocore
    import boto3

    if not (os.getenv("BUCKET_NAME") and os.getenv("DB_NAME")):
        logger.error("Please set environment variables")
        exit()

    logger.info(f"Getting database file from s3 bucket - {os.getenv('BUCKET_NAME')}...")
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(os.getenv("BUCKET_NAME"))
    try:
        object = bucket.Object(os.getenv("DB_NAME"))
        object.download_file('/tmp/'+os.getenv("DB_NAME"))
        logger.info(f"Fetched DB file - {os.getenv('DB_NAME')}")
    except botocore.exceptions.ClientError:
        logger.error("Failed to fetch file or no file exists. Exiting...")
        raise

    # connect to database and perform SCD Type 2 transformation
    # STAGING table holds scraped records and FINAL table holds all records from beginning
    logger.info(f"Performaing data transformations...")
    db = sq.connect('/tmp/'+os.getenv("DB_NAME"))
    db.create_function("hash", 1, _hash_row)
    db.execute("""
    create table PRE_FINAL AS
    select headline, news_category, news_url, source_name, source_url, published_author, published_datetime, key_hash, update_date from FINAL
    UNION
    select t1.headline, t1.news_category, t1.news_url, t1.source_name, t1.source_url, t1.published_author, t1.published_datetime, t1.key_hash, min(t1.update_date) from STAGING t1
    inner join
    (select key_hash, hash(headline || news_category || source_name || source_url || published_author || published_datetime) as change_hash from STAGING
    EXCEPT
    select key_hash, hash(headline || news_category || source_name || source_url || published_author || published_datetime) as change_hash from FINAL) t2
    on t1.key_hash = t2.key_hash
    group by t1.headline, t1.news_category, t1.news_url, t1.source_name, t1.source_url, t1.published_author, t1.published_datetime, t1.key_hash
    """)
    db.commit()
    logger.info(f"STEP 1 completed, created PRE_FINAL")
    db.execute("delete from FINAL")
    logger.info(f"STEP 2 completed, truncated FINAL")
    db.execute("""
    INSERT into FINAL
    select headline, news_category, news_url, source_name, source_url, published_author, published_datetime, key_hash, update_date
    from PRE_FINAL
    """)
    logger.info(f"STEP 3 completed, inserted records into FINAL")
    db.execute("drop table PRE_FINAL")
    logger.info(f"STEP 4 completed, dropped FINAL")
    db.commit()
    db.close()

    logger.info(f"Finished data transformations. Uploading data back to s3...")
    try:
        bucket = s3.Bucket(os.getenv("UPLOAD_BUCKET_NAME"))
        bucket.upload_file('/tmp/'+os.getenv("DB_NAME"), os.getenv("DB_NAME"))
        logger.info(f"DB file upload finished")
    except:
        logger.error(f"Error while uploading file")
        raise